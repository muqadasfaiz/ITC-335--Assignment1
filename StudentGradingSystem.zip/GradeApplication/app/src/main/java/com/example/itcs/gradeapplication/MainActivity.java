package com.example.itcs.gradeapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button showGrade = (Button) findViewById(R.id.showGradebtn);
        showGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {

                EditText StudentID = (EditText) findViewById(R.id.studentID);
                EditText CourseCode = (EditText) findViewById(R.id.courseCode);
                EditText TotalMarks = (EditText) findViewById(R.id.totalMarks);
                TextView StudentIDValue = (TextView) findViewById(R.id.showSIDValue);
                TextView CourseCodeValue = (TextView) findViewById(R.id.showCCValue);
                TextView TotalMarksValue = (TextView) findViewById(R.id.showTMValue);
                TextView GradeValue = (TextView) findViewById(R.id.showGValue);
                TextView StudentIDLabel = (TextView) findViewById(R.id.showResultSID);
                TextView CourseCodeLabel = (TextView) findViewById(R.id.showResultCC);
                TextView TotalMarksLabel = (TextView) findViewById(R.id.showResultTM);
                TextView GradeLabel = (TextView) findViewById(R.id.showResultG);


                int x = Integer.parseInt(StudentID.getText().toString());
                String y = CourseCode.getText().toString();
                float z = Float.parseFloat(TotalMarks.getText().toString());

                if (z >= 94 && z <= 100) {
                    GradeValue.setText("A");
                }
                else if (z >= 90 && z <= 94) {
                    GradeValue.setText("A-");
                }
                else if (z >= 87 && z <= 90) {
                    GradeValue.setText("B+");
                }
                else if (z >= 84 && z <= 87) {
                    GradeValue.setText("B");
                }
                else if (z >= 80 && z <= 84) {
                    GradeValue.setText("B-");
                }
                else if (z >= 77 && z <= 80) {
                    GradeValue.setText("C+");
                }
                else if (z >= 74 && z <= 77) {
                    GradeValue.setText("C");
                }
                else if (z >= 70 && z <= 74) {
                    GradeValue.setText("C-");
                }
                else if (z >= 67 && z <= 70) {
                    GradeValue.setText("D+");
                }
                else if (z >= 60 && z <= 67) {
                    GradeValue.setText("D");
                }
                else if (z >= 0 && z <= 60) {
                    GradeValue.setText("F");
                }
                else {
                    GradeValue.setText("Entry out of range!");
                }

                StudentIDValue.setText(x + "");
                CourseCodeValue.setText(y + "");
                TotalMarksValue.setText(z + "");
                StudentIDLabel.setText("Student ID");
                CourseCodeLabel.setText("Course Code");
                TotalMarksLabel.setText("Total Marks");
                GradeLabel.setText("Grade");

            }
        });
    }
}
